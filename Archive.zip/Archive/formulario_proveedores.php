<!-- Formulario estilizado con validaciones y fondo. -->
