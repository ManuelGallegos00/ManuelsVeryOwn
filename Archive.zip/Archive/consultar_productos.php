<?php
include 'conexion.php';
$resultado = mysqli_query($conn, "SELECT * FROM Productos");
echo "<table border='1'><tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Tipo</th><th>Acción</th></tr>";
while ($row = mysqli_fetch_assoc($resultado)) {
    echo "<tr>
            <td>{$row['IdProducto']}</td>
            <td>{$row['Nombre']}</td>
            <td>{$row['Precio']}</td>
            <td>{$row['Tipo']}</td>
            <td><a href='formulario_producto.php?modificar={$row['IdProducto']}'>Modificar</a></td>
          </tr>";
}
echo "</table>";
?>
