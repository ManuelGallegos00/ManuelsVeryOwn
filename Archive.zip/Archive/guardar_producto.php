<?php
include 'conexion.php';
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$precio = $_POST['precio'];
$tipo = $_POST['tipo'];

$query = "UPDATE Productos SET Nombre='$nombre', Precio=$precio, Tipo='$tipo' WHERE IdProducto=$id";
mysqli_query($conn, $query);
header("Location: formulario_producto.php");
?>
