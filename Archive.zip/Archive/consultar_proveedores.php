<!-- Tabla de proveedores con fondo blanco para contraste. -->
