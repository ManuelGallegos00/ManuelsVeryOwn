<?php
// Lógica para eliminar producto
?>