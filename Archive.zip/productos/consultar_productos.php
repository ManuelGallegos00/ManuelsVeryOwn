<?php
// Tabla de productos
?>