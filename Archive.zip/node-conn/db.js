const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'SupermercadoLeoncio',
  port: 3306
});

connection.connect(err => {
  if (err) {
    console.error('Error al conectar a la BD:', err.message);
    process.exit(1);
  }
  console.log('¡Conectado a MySQL!');
});

connection.query('SHOW TABLES', (err, results) => {
  if (err) {
    console.error('Error en la consulta:', err.message);
  } else {
    console.log('Tablas en la base de datos:', results);
  }
  connection.end();
});
