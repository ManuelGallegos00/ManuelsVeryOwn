<?php
include('../conexion.php');

$result = $conn->query("SELECT * FROM productos");

echo "<h2>Lista de Productos</h2>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Nombre</th><th>Marca</th><th>Precio</th><th>Cantidad</th><th>Tipo</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$row['IdProducto']}</td>
            <td>{$row['Nombre']}</td>
            <td>{$row['Marca']}</td>
            <td>{$row['Precio']}</td>
            <td>{$row['Cantidad']}</td>
            <td>{$row['Tipo']}</td>
          </tr>";
}
echo "</table>";
?>