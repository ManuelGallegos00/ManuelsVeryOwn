<?php
// Lógica para guardar producto
?>