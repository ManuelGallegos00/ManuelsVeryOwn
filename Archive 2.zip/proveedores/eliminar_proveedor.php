<?php
// Lógica para eliminar proveedor
?>