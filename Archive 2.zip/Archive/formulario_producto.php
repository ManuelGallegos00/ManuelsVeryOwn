<?php
include 'conexion.php';

$nombre = '';
$precio = '';
$empaque = '';

if (isset($_GET['modificar'])) {
    $id = $_GET['modificar'];
    $query = "SELECT * FROM Productos WHERE IdProducto = $id";
    $result = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_assoc($result)) {
        $nombre = $row['Nombre'];
        $precio = $row['Precio'];
        $empaque = $row['Tipo'];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Producto</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h2>Formulario de Producto</h2>
    <form action="guardar_producto.php" method="post">
        <input type="hidden" name="id" value="<?php echo $_GET['modificar'] ?? ''; ?>">
        <label>Nombre:</label>
        <input type="text" name="nombre" value="<?php echo $nombre; ?>"><br>
        <label>Precio:</label>
        <input type="number" name="precio" step="0.01" value="<?php echo $precio; ?>"><br>
        <label>Tipo de empaque:</label>
        <input type="text" name="tipo" value="<?php echo $empaque; ?>"><br>
        <button type="submit">Guardar</button>
    </form>
    <hr>
    <?php include 'consultar_productos.php'; ?>
</body>
</html>
