<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $id = $_POST['id_eliminar'];
  $sql = "DELETE FROM Productos WHERE IdProducto = $id";
  if (mysqli_query($conn, $sql)) {
    echo "<div class='alert success'>Producto eliminado exitosamente.</div>";
  } else {
    echo "<div class='alert error'>Error al eliminar: " . mysqli_error($conn) . "</div>";
  }
  mysqli_close($conn);
}
?>